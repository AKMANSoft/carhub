# Carhub

<https://carhub.mi6.global>

# Please make sure Google Maps Api is enabled because the provided Google Api Key is not working with location.

# Please provide Find Me Buyer Screen design sample.

# CORS Issue

Here is loom of the CORS issue on add-car endpoint (CORS issues is occuring on all post request).
<https://www.loom.com/share/4eedac7d0bbb4ff3a48597cd8b4ab872>
CORS issue coming on all POST requests

# Other Issues

1. There is no endpoint to send message.
2. There is no endpoint to get users public profiles.
3. No endpoint for Reviews.
4. No endpoint for Get Offers.
5. No endpoint to get My Cars (current seller cars).
6. No endpoint for Make Offer on car profile page.

# Tutorial Doc About How to get api key from google console

<https://docs.google.com/document/d/1DQPeBEgKs7B5sXDdiGLMFXmtc3_0kwVzBqIU_UupY9o/edit?usp=sharing>
It's not mentioned in document but have to enable maps api in google console in order to use location
