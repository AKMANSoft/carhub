
export const MAIN_HORIZONTAL_PADDING = " px-4 lg:px-10 2xl:px-20 "

